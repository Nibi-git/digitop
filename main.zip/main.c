//��������� ��� ���������� ������ ������� ������� �� ���������� ���������� � ����
//�� ������ Tiny26
#include <ioavr.h>
#include <intrinsics.h>

#include "hardware.h"

#include "segments.h"

//volatile unsigned char MeasureCounter;
volatile unsigned char ResultSummReady;

__flash signed int segmentsDec[5]={10000,1000,100,10,1};
unsigned char String[5];

void CharToStringDec(signed int inp)
{
unsigned char i;
String[0]=String[1]=String[2]=String[3]=String[4]=0;
// �������
for(i=0;i<5;)
  {
  if((inp-segmentsDec[i])>=0)
    {
    inp-=segmentsDec[i];
    String[i]++;
    }
  else i++;
  }
}

void InitPorts (void)
{

PortButton |= (1<<Button_DN)|(1<<Button_UP); // ������������� ���������

PortAnodeDir |= ((1<<SEG_A)|(1<<SEG_B)|(1<<SEG_C)|(1<<SEG_D)|(1<<SEG_E)|(1<<SEG_F)|(1<<SEG_G)|(1<<SEG_DP));
PortKathodeDir |= ((1<<Kathode_1) | (1<<Kathode_2) | (1<<Kathode_3));

PortRelayDir |= (1<<Relay);

}

void InitADC (void)
{
ADMUX = ((2<<REFS0)|(InADC << MUX0));
ADCSR = ((1 << ADEN)|(5 << ADPS0)|(0<<ADFR)|(0<<ADSC)|(0<<ADIE));

//5 << ADPS0 Prescaler = 32  f = 8000000/(32*13)=19230 ��
//6 << ADPS0 Prescaler = 64  f = 8000000/(64*13)=9615 ��
//7 << ADPS0 Prescaler = 128
}

void InitTimers (void)
{
TCCR0 |= (3<<CS00);//3
TCCR1B |= (4<<CS10);//3
TIMSK |= ((1<<TOIE0)|(1<<TOIE1));
}

unsigned int InputValue;//, MaxInputValue;
volatile unsigned int DisplayValue;
unsigned char cycle_count;//, //Brightness = 2;
unsigned char VideoBuffer[3];
unsigned int keypress[2], KeyTimer;
unsigned int ProtectTimerMaxValue, ProtectTimerValue;
__eeprom unsigned int ProtectTimerMaxValueEEPROM;

unsigned int Voltage, UpTreshold, DownTreshold;

__eeprom unsigned int UpTresholdEEPROM, DownTresholdEEPROM;

unsigned char DisplayMode = RealtimeVoltage;

unsigned char EnableDisplay = 1;

void SaveSettings (void)
{
UpTresholdEEPROM = UpTreshold;
DownTresholdEEPROM = DownTreshold;
ProtectTimerMaxValueEEPROM = ProtectTimerMaxValue;
}

void CheckTresholdSettings (void)
{
if (UpTreshold > 270) UpTreshold = 270;
if (UpTreshold < 210) UpTreshold = 210;

if (DownTreshold > 200) DownTreshold = 200;
if (DownTreshold < 120) DownTreshold = 120;
}

void CheckTimerSettings (void)
{
if (ProtectTimerMaxValue > 600) ProtectTimerMaxValue = 600;
if (ProtectTimerMaxValue < 5) ProtectTimerMaxValue = 5;
}

void LoadSettings (void)
{
UpTreshold = UpTresholdEEPROM;
DownTreshold = DownTresholdEEPROM;
ProtectTimerMaxValue = ProtectTimerMaxValueEEPROM;

CheckTresholdSettings ();
CheckTimerSettings ();
}

void UpdateLedScreen (void)
{
VideoBuffer[0] = 0x00;
VideoBuffer[1] = 0x00;
VideoBuffer[2] = 0x00;

switch (DisplayMode)
{
case RealtimeVoltage:     DisplayValue = Voltage;               break;
case UpTresholdVoltage:   DisplayValue = UpTreshold;            break;
case DownTresholdVoltage: DisplayValue = DownTreshold;          break;
case UpTresholdTune:      DisplayValue = UpTreshold;            break;
case DownTresholdTune:    DisplayValue = DownTreshold;          break;
case ProtectTimerTune:    DisplayValue = ProtectTimerMaxValue;  break;
case ProtectTimer:        DisplayValue = ProtectTimerValue;     break;
}

CharToStringDec(DisplayValue);

if (EnableDisplay)//
  {
  VideoBuffer[0] = led_digits[String[2]];
  VideoBuffer[1] = led_digits[String[3]];
  VideoBuffer[2] = led_digits[String[4]];
  
  if ((DisplayMode == DownTresholdTune)||(DisplayMode == UpTresholdTune)||(DisplayMode == ProtectTimerTune))
    {
    VideoBuffer[2] |= led_digits[0x10];
    }
  }

}

volatile unsigned long SummUUResult; // �������� �������� �����
unsigned long SummUU; // ���������� ��������
unsigned char SamplesCounter;

#pragma vector = TIMER1_OVF1_vect ///ADC_vect 
__interrupt void ADCSampleReady (void)
{
unsigned long temp;
TCNT1 = T1_RELOAD; // ������������� ������

//unsigned int temp;
temp = ADC;

ADCSR |= (1<<ADSC);

if (temp > 3)//temp > 5
  {
  //ResultSummReady = 0;
  //if (InputValue > MaxInputValue) MaxInputValue = InputValue;
  
  temp *= temp; // �������� � �������
  SummUU += temp;
  
  SamplesCounter++;
  }

  else 
  {
  if (SamplesCounter > 10)
    {
    SummUUResult = SummUU;
    SummUU = 0;
    SamplesCounter = 0;
    ResultSummReady = 1;
    }
  }


/*
InputValue = ADC;
if (InputValue > MaxInputValue) MaxInputValue = InputValue;
*/
}

void PressProcessing (unsigned char code_state)
{
switch (code_state)
{
case DN_SHORT:
  switch (DisplayMode)
  {
  case RealtimeVoltage:       DisplayMode = DownTresholdVoltage;                break;
  case UpTresholdVoltage:     DisplayMode = DownTresholdVoltage;                break;
  case DownTresholdTune:      DownTreshold --; CheckTresholdSettings ();        break;
  case UpTresholdTune:        UpTreshold --;   CheckTresholdSettings ();        break;
  case ProtectTimerTune:      ProtectTimerMaxValue -=5; CheckTimerSettings ();  break;
  case ProtectTimer:          DisplayMode = DownTresholdVoltage;                break;
  }
break;

case UP_SHORT:
  switch (DisplayMode)
  {
  case RealtimeVoltage:       DisplayMode = UpTresholdVoltage;                  break;
  case DownTresholdVoltage:   DisplayMode = UpTresholdVoltage;                  break;
  case DownTresholdTune:      DownTreshold ++; CheckTresholdSettings ();        break;
  case UpTresholdTune:        UpTreshold ++;   CheckTresholdSettings ();        break;
  case ProtectTimerTune:      ProtectTimerMaxValue +=5; CheckTimerSettings ();  break;
  case ProtectTimer:          DisplayMode = UpTresholdVoltage;                  break;  
  }
break;

case DN_MID:
if (DisplayMode == DownTresholdVoltage) DisplayMode = DownTresholdTune;
break;

case UP_MID:
if (DisplayMode == UpTresholdVoltage) DisplayMode = UpTresholdTune;
break;

case DN_UP_MID:
  switch (DisplayMode)
  {
  case DownTresholdVoltage:   DisplayMode = ProtectTimerTune;        break;
  case UpTresholdVoltage:     DisplayMode = ProtectTimerTune;      break;
  }
break;
}

}

#pragma vector = TIMER0_OVF0_vect 
__interrupt void DynInd (void)
{
//__enable_interrupt(); // ������ SIGNAL
TCNT0 = T0_RELOAD; // ������������� ������

//if (MeasureCounter) MeasureCounter--;
if (cycle_count == 2) // ��������� ����� ������
  {
  if (!(PinButton & (1<<Button_DN))) {keypress[0]++; KeyTimer = KeyTimerMax;}
  else keypress[0]=0;
  }

if (cycle_count == 0) // ��������� ������ ������
  {
  if (!(PinButton & (1<<Button_UP))) {keypress[1]++; KeyTimer = KeyTimerMax;}
  else keypress[1]=0;
  }

if ((keypress[0] == shortpress)&&(keypress[1] == 0))  {  keypress[0]++;  PressProcessing(DN_SHORT);  }
if ((keypress[1] == shortpress)&&(keypress[0] == 0))  {  keypress[1]++;  PressProcessing(UP_SHORT);  }

if ((keypress[0] == midpress)&&(keypress[1] == 0))  {  keypress[0] = midpress+5;  PressProcessing(DN_MID);  }
if ((keypress[1] == midpress)&&(keypress[0] == 0))  {  keypress[1] = midpress+5;  PressProcessing(UP_MID);  }

if ((keypress[0] == midpress)&&(keypress[1] > shortpress))  {  keypress[0] = midpress+5; keypress[1] = midpress+5; PressProcessing(DN_UP_MID);  }


if ((keypress[0] > longpress)&&(keypress[1] == 0))  {  keypress[0] = longpress+5; }
if ((keypress[1] > longpress)&&(keypress[0] == 0))  {  keypress[1] = longpress+5; }

if ((keypress[0] > longpress)&&(keypress[1] > longpress))  {  keypress[0] = longpress+5; keypress[1] = longpress+5; }


if ((keypress[0] == 0)&&(keypress[1] == 0)&&(KeyTimer)) KeyTimer--;
if (KeyTimer == 1) 
  {
  DisplayMode = RealtimeVoltage;
  SaveSettings ();
  }

if (cycle_count < NUMBER_DIGITS)
  {
  PortKathode |= ((1<<Kathode_1) | (1<<Kathode_2) | (1<<Kathode_3)); //�������� ��� �������
  PortAnode &= ~((1<<SEG_A)|(1<<SEG_B)|(1<<SEG_C)|(1<<SEG_D)|(1<<SEG_E)|(1<<SEG_F)|(1<<SEG_G)|(1<<SEG_DP));

  PortAnode = VideoBuffer[cycle_count]; // ������ ����� �������� ��� ������
  PortKathode &= ~ArrayKathodes[cycle_count];// �������� �����
  }

if (++cycle_count > 2) 
  {
  cycle_count=0;
  UpdateLedScreen ();
  }
}

#define Koef 692//294 //64 max

unsigned char QuarterSecPrescaler, SecPrescaler;

unsigned long isqrt (unsigned long v)
{
unsigned long temp, nHat=0, b=0x8000, bshft=15;
do{
  if (v >= (temp = (((nHat<<1)+b)<<bshft--)))    {    nHat += b;    v -= temp;    }
  }while (b>>=1);
return nHat;
}

int main( void )
{
InitPorts ();
InitTimers ();
InitADC ();
LoadSettings ();
ProtectTimerValue = ProtectTimerStartValue;
__enable_interrupt();

  while (1)
  {
  __delay_cycles((CtrlClockRate/1000)*100);
  //SummUU = 0; // ���������� ����� ��������� �������� ���
  //SamplesCounter = 0;
  //ResultSummReady = 0;

  //while (!ResultSummReady) {}
  if (ResultSummReady)
  {
  ResultSummReady = 0;
  //Voltage = SummUUResult;
  SummUUResult = SummUUResult/SamplesCount;
  Voltage = (unsigned int)(isqrt(SummUUResult)*Koef/1000);//*Koef/1000
  }
  
  // ���� 20 �� � ���������� ������
  //Voltage = (unsigned int)((unsigned long)MaxInputValue);//*Koef/1000 //480A
  //
  //MaxInputValue = 0; // ���������� ��������
  
  //Voltage = SamplesCounter;
  
  
  if ((Voltage > UpTreshold) || (Voltage < DownTreshold))    ProtectTimerValue = ProtectTimerMaxValue;
   // else                                                     ProtectTimerValue = 0;

if ((ProtectTimerValue == ProtectTimerMaxValue)&&(DisplayMode == ProtectTimer)) DisplayMode = RealtimeVoltage;
if ((ProtectTimerValue == (ProtectTimerMaxValue - 1))&&(DisplayMode == RealtimeVoltage)) DisplayMode = ProtectTimer;
if ((ProtectTimerValue == 0)&&(DisplayMode == ProtectTimer)) DisplayMode = RealtimeVoltage;
  
  if (ProtectTimerValue) PortRelay &= ~(1<<Relay);
    else   PortRelay |= (1<<Relay);
    
  if (QuarterSecPrescaler++>5)    //��� � �������� ������� ���� �������
    {
    QuarterSecPrescaler = 0;
    if ((ProtectTimerValue == ProtectTimerMaxValue)&&(DisplayMode == RealtimeVoltage))
      {
      if (EnableDisplay) EnableDisplay = 0;
        else EnableDisplay = 1;
      }
      else EnableDisplay = 1;

//�������������!!   
    /*
if (((ProtectTimerMaxValue - ProtectTimerValue) > 2)&&(DisplayMode == RealtimeVoltage)) DisplayMode = ProtectTimer;
if (((ProtectTimerMaxValue - ProtectTimerValue) < 2)&&(DisplayMode == ProtectTimer)) DisplayMode = RealtimeVoltage;
    */

    }
  
  if (SecPrescaler++>15)
  {
  SecPrescaler = 0;
  if (ProtectTimerValue) ProtectTimerValue--;
  }
  
  }
}
